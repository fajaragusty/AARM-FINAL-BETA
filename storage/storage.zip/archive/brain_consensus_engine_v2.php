<?php

/*
|--------------------------------------------------------------------------
| ANTARTIKA
| Brain Consensus Engine V2
|--------------------------------------------------------------------------
*/

$brainFile =
    __DIR__.'/storage/brain_state.json';

$statusFile =
    __DIR__.'/storage/knowledge_status.json';

$outputFile =
    __DIR__.'/storage/brain_consensus_v2.json';

foreach([
    $brainFile,
    $statusFile
] as $file){

    if(!file_exists($file)){
        exit(
            basename($file)
            .' NOT FOUND'
        );
    }

}

$brain =
    json_decode(
        file_get_contents($brainFile),
        true
    ) ?: [];

$statusData =
    json_decode(
        file_get_contents($statusFile),
        true
    ) ?: [];

/*
|--------------------------------------------------------------------------
| Status Weight
|--------------------------------------------------------------------------
*/

$statusWeight = [

    'ACTIVE'     => 1.00,
    'UNPROVEN'   => 0.60,
    'DECAYING'   => 0.40,
    'DEAD'       => 0.20,
    'GRAVEYARD'  => 0.00

];

$callWeight = 0;
$putWeight  = 0;

$reasons = [];

/*
|--------------------------------------------------------------------------
| Pattern Brain
|--------------------------------------------------------------------------
*/
/*
|--------------------------------------------------------------------------
| Pattern Brain
|--------------------------------------------------------------------------
*/

$patternVote =
    $brain['pattern_vote']
    ?? 'WAIT';

$patternScore =
    $brain['pattern_score']
    ?? 0;

$patternKey =
    $brain['pattern_key']
    ?? '';

$status =
    $statusData[$patternKey]['status']
    ?? 'UNPROVEN';

$weight =
    $statusWeight[$status]
    ?? 0.60;

$final =
    round(
        $patternScore * $weight,
        2
    );

if($patternVote === 'CALL'){
    $callWeight += $final;
}

if($patternVote === 'PUT'){
    $putWeight += $final;
}

$reasons[] = [

    'brain' =>
        'PATTERN',

    'vote' =>
        $patternVote,

    'score' =>
        $patternScore,

    'status' =>
        $status,

    'weight' =>
        $weight,

    'final' =>
        $final

];

/*
|--------------------------------------------------------------------------
| Digit Brain
|--------------------------------------------------------------------------
*/
/*
|--------------------------------------------------------------------------
| Digit Brain
|--------------------------------------------------------------------------
*/

$digitVote =
    $brain['digit_vote']
    ?? 'WAIT';

$digitScore =
    $brain['digit_score']
    ?? 0;

$digitKey =
    $brain['digit_key']
    ?? '';

$status =
    $statusData[$digitKey]['status']
    ?? 'UNPROVEN';

$weight =
    $statusWeight[$status]
    ?? 0.60;

$final =
    round(
        $digitScore * $weight,
        2
    );

if($digitVote === 'CALL'){
    $callWeight += $final;
}

if($digitVote === 'PUT'){
    $putWeight += $final;
}

$reasons[] = [

    'brain' =>
        'DIGIT',

    'vote' =>
        $digitVote,

    'score' =>
        $digitScore,

    'status' =>
        $status,

    'weight' =>
        $weight,

    'final' =>
        $final

];
/*
|--------------------------------------------------------------------------
| Decision
|--------------------------------------------------------------------------
*/

$decision = 'WAIT';

$delta =
    abs(
        $callWeight
        -
        $putWeight
    );

if($delta >= 10){

    if($callWeight > $putWeight){

        $decision =
            'FOLLOW_CALL';

    }else{

        $decision =
            'FOLLOW_PUT';

    }

}

$total =
    $callWeight
    +
    $putWeight;

$confidence = 0;

if($total > 0){

    $confidence = round(

        (
            max(
                $callWeight,
                $putWeight
            )
            /
            $total
        ) * 100,

        2

    );

}

/*
|--------------------------------------------------------------------------
| Save
|--------------------------------------------------------------------------
*/

$result = [

    'time' =>
        date('Y-m-d H:i:s'),

    'call_weight' =>
        round(
            $callWeight,
            2
        ),

    'put_weight' =>
        round(
            $putWeight,
            2
        ),

    'delta' =>
        round(
            $delta,
            2
        ),

    'confidence' =>
        $confidence,

    'decision' =>
        $decision,

    'brains' =>
        $reasons

];

file_put_contents(

    $outputFile,

    json_encode(
        $result,
        JSON_PRETTY_PRINT
    )

);

echo 'BRAIN CONSENSUS V2 UPDATED';