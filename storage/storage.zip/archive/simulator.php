<?php

$tickFile =
    __DIR__.'/storage/ticks.json';

$tradeFile =
    __DIR__.'/storage/paper_trades.json';

$signalFile =
    __DIR__.'/storage/signals.json';

$ticks = json_decode(
    file_get_contents($tickFile),
    true
) ?: [];

$trades = json_decode(
    file_get_contents($tradeFile),
    true
) ?: [];

$signals = json_decode(
    file_get_contents($signalFile),
    true
) ?: [];

if(count($ticks) < 10){
    exit('WAIT');
}

if(empty($signals)){
    exit('NO SIGNAL');
}

$currentTickIndex =
    count($ticks) - 1;

$lastTrade =
    end($trades);

$lastSignal =
    end($signals);

/*
|--------------------------------------------------------------------------
| OPEN NEW TRADE FROM SIGNAL
|--------------------------------------------------------------------------
*/

$canOpenTrade = false;

if(
    !$lastTrade
){
    $canOpenTrade = true;
}
else{

    if(
        ($lastTrade['result'] ?? null)
        !== null
    ){
        $canOpenTrade = true;
    }

}

if($canOpenTrade){

    $alreadyUsed =
        (
            $lastTrade['signal_time']
            ?? 0
        )
        ==
        (
            $lastSignal['time']
            ?? -1
        );

    if(!$alreadyUsed){

        $trades[] = [

            'signal_time' =>
                $lastSignal['time'],

            'entry_tick' =>
                $currentTickIndex,

            'entry_price' =>
                $ticks[$currentTickIndex]['quote'],

            'direction' =>
                $lastSignal['direction'],

            'pattern' =>
                $lastSignal['pattern'],

            'duration' => 3,

            'result' => null

        ];

    }

}

/*
|--------------------------------------------------------------------------
| PROCESS OPEN TRADES
|--------------------------------------------------------------------------
*/

foreach($trades as &$trade){

    if(
        ($trade['result'] ?? null)
        !== null
    ){
        continue;
    }

    $exitIndex =
        $trade['entry_tick']
        +
        $trade['duration'];

    if(
        $currentTickIndex
        >=
        $exitIndex
    ){

        $exitPrice =
            $ticks[$exitIndex]['quote'];

        $trade['exit_price'] =
            $exitPrice;

        if(
            $trade['direction']
            ===
            'CALL'
        ){

            $trade['result'] =
                (
                    $exitPrice >
                    $trade['entry_price']
                )
                ?
                'WIN'
                :
                'LOSS';

        }
        else{

            $trade['result'] =
                (
                    $exitPrice <
                    $trade['entry_price']
                )
                ?
                'WIN'
                :
                'LOSS';

        }

    }

}

unset($trade);

file_put_contents(

    $tradeFile,

    json_encode(
        $trades,
        JSON_PRETTY_PRINT
    )

);

echo 'SIMULATOR UPDATED';