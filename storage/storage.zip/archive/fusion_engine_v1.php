<?php

/*
|--------------------------------------------------------------------------
| ANTARTIKA
| Fusion Engine V1
|--------------------------------------------------------------------------
*/

$patternFile =
    __DIR__.'/storage/knowledge_scores.json';

$digitFile =
    __DIR__.'/storage/digit_scores.json';

$outputFile =
    __DIR__.'/storage/fusion_knowledge.json';

if(!file_exists($patternFile)){
    exit('knowledge_scores.json NOT FOUND');
}

if(!file_exists($digitFile)){
    exit('digit_scores.json NOT FOUND');
}

$patterns = json_decode(
    file_get_contents($patternFile),
    true
) ?: [];

$digits = json_decode(
    file_get_contents($digitFile),
    true
) ?: [];

if(empty($patterns)){
    exit('NO PATTERN DATA');
}

if(empty($digits)){
    exit('NO DIGIT DATA');
}

$fusion = [];

/*
|--------------------------------------------------------------------------
| Top Pattern Candidates
|--------------------------------------------------------------------------
*/

$topPatterns =
    array_slice(
        $patterns,
        0,
        20,
        true
    );

/*
|--------------------------------------------------------------------------
| Top Digit Candidates
|--------------------------------------------------------------------------
*/

$topDigits =
    array_slice(
        $digits,
        0,
        20,
        true
    );

/*
|--------------------------------------------------------------------------
| Fusion
|--------------------------------------------------------------------------
*/

foreach($topPatterns as $pKey => $pattern){

    foreach($topDigits as $dKey => $digit){

        $status =
            (
                $pattern['direction']
                ===
                $digit['direction']
            )
            ?
            'AGREEMENT'
            :
            'CONFLICT';

        $fusionScore = round(

            (
                $pattern['score']
                +
                $digit['score']
            ) / 2,

            2

        );

        $fusionKey =

            $pKey

            .' + '

            .$dKey;

        $fusion[$fusionKey] = [

            'status' =>
                $status,

            'pattern_direction' =>
                $pattern['direction'],

            'digit_direction' =>
                $digit['direction'],

            'pattern_score' =>
                $pattern['score'],

            'digit_score' =>
                $digit['score'],

            'fusion_score' =>
                $fusionScore,

            'pattern' =>
                $pattern['pattern']
                ?? '',

            'digit' =>
                $digit['digit']
                ?? ''

        ];

    }

}

/*
|--------------------------------------------------------------------------
| Sort By Fusion Score
|--------------------------------------------------------------------------
*/

uasort(

    $fusion,

    function($a,$b){

        return
            $b['fusion_score']
            <=>
            $a['fusion_score'];

    }

);

/*
|--------------------------------------------------------------------------
| Save
|--------------------------------------------------------------------------
*/

file_put_contents(

    $outputFile,

    json_encode(

        $fusion,

        JSON_PRETTY_PRINT

    )

);

echo 'FUSION ENGINE UPDATED';