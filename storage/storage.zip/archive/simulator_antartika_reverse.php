<?php

error_reporting(E_ALL);

/*
|--------------------------------------------------------------------------
| ANTARTIKA REVERSE SIMULATOR
|--------------------------------------------------------------------------
| Menguji:
| Consensus Direction
| VS
| Reverse Direction
|--------------------------------------------------------------------------
*/

$tickFile =
    __DIR__.'/storage/historical_ticks.json';

$knowledgeFile =
    __DIR__.'/storage/knowledge_status.json';

$digitFile =
    __DIR__.'/storage/digit_scores.json';

$outputFile =
    __DIR__.'/storage/reverse_simulator_result.json';

if(!file_exists($tickFile)){
    exit('historical_ticks.json NOT FOUND');
}

if(!file_exists($knowledgeFile)){
    exit('knowledge_status.json NOT FOUND');
}

if(!file_exists($digitFile)){
    exit('digit_scores.json NOT FOUND');
}

$ticks =
    json_decode(
        file_get_contents($tickFile),
        true
    ) ?: [];

$knowledge =
    json_decode(
        file_get_contents($knowledgeFile),
        true
    ) ?: [];

$digits =
    json_decode(
        file_get_contents($digitFile),
        true
    ) ?: [];

function getRsiZone($rsi)
{
    if($rsi < 20) return 'RSI_0_20';
    if($rsi < 40) return 'RSI_20_40';
    if($rsi < 60) return 'RSI_40_60';
    if($rsi < 80) return 'RSI_60_80';

    return 'RSI_80_100';
}

$totalTrades = 0;

$consensusWins = 0;
$consensusLoss = 0;

$reverseWins = 0;
$reverseLoss = 0;

$waitSignals = 0;

for($i=3;$i<count($ticks)-10;$i++){

    /*
    |--------------------------------------------------------------------------
    | Pattern Brain
    |--------------------------------------------------------------------------
    */

    $t1 = $ticks[$i-3]['quote'];
    $t2 = $ticks[$i-2]['quote'];
    $t3 = $ticks[$i-1]['quote'];
    $t4 = $ticks[$i]['quote'];

    $pattern =
        (($t2>$t1)?'U':'D').
        (($t3>$t2)?'U':'D').
        (($t4>$t3)?'U':'D');

    $rsiZone =
        getRsiZone(
            $ticks[$i]['rsi'] ?? 50
        );

    $trend =
        $ticks[$i]['trend']
        ?? 'UNKNOWN';

    $market =
        $ticks[$i]['market_state']
        ?? 'UNKNOWN';

    $patternBrain = null;

    foreach($knowledge as $key=>$row){

        if(
            ($row['status'] ?? '')
            !== 'ACTIVE'
        ){
            continue;
        }

        $parts =
            explode('|',$key);

        if(count($parts) < 6){
            continue;
        }

        if($parts[0] !== $pattern) continue;
        if($parts[3] !== $rsiZone) continue;
        if($parts[4] !== $trend) continue;
        if($parts[5] !== $market) continue;

        $patternBrain = $row;
        break;
    }

    if(!$patternBrain){
        continue;
    }

    /*
    |--------------------------------------------------------------------------
    | Digit Brain
    |--------------------------------------------------------------------------
    */

    $quote =
        (string)$ticks[$i]['quote'];

    $digit =
        substr(
            preg_replace('/\D/','',$quote),
            -1
        );

    $digitBrain = null;

    foreach($digits as $row){

        if(
            (string)$row['digit']
            !== $digit
        ){
            continue;
        }

        if(
            ($row['wr'] ?? 0)
            < 53
        ){
            continue;
        }

        if(
            ($row['samples'] ?? 0)
            < 200
        ){
            continue;
        }

        $digitBrain = $row;
        break;
    }

    if(!$digitBrain){
        continue;
    }

    /*
    |--------------------------------------------------------------------------
    | Consensus Check
    |--------------------------------------------------------------------------
    */

    if(
        $patternBrain['direction']
        !==
        $digitBrain['direction']
    ){

        $waitSignals++;
        continue;
    }

    $direction =
        $patternBrain['direction'];

    $reverseDirection =
        (
            $direction === 'CALL'
        )
        ? 'PUT'
        : 'CALL';

    $duration =
        intval(
            $patternBrain['duration']
        );

    if(
        !isset(
            $ticks[$i+$duration]
        )
    ){
        continue;
    }

    $entry =
        $ticks[$i]['quote'];

    $exit =
        $ticks[$i+$duration]['quote'];

    /*
    |--------------------------------------------------------------------------
    | Consensus Result
    |--------------------------------------------------------------------------
    */

    $consensusWin = false;

    if($direction === 'CALL'){

        $consensusWin =
            $exit > $entry;

    }else{

        $consensusWin =
            $exit < $entry;
    }

    /*
    |--------------------------------------------------------------------------
    | Reverse Result
    |--------------------------------------------------------------------------
    */

    $reverseWin = false;

    if($reverseDirection === 'CALL'){

        $reverseWin =
            $exit > $entry;

    }else{

        $reverseWin =
            $exit < $entry;
    }

    $totalTrades++;

    if($consensusWin){

        $consensusWins++;

    }else{

        $consensusLoss++;
    }

    if($reverseWin){

        $reverseWins++;

    }else{

        $reverseLoss++;
    }
}

/*
|--------------------------------------------------------------------------
| Stats
|--------------------------------------------------------------------------
*/

$consensusWR = 0;
$reverseWR = 0;

if($totalTrades > 0){

    $consensusWR =
        round(
            ($consensusWins/$totalTrades)*100,
            2
        );

    $reverseWR =
        round(
            ($reverseWins/$totalTrades)*100,
            2
        );
}

$result = [

    'total_trades' =>
        $totalTrades,

    'wait_signals' =>
        $waitSignals,

    'consensus' => [

        'wins' =>
            $consensusWins,

        'losses' =>
            $consensusLoss,

        'wr' =>
            $consensusWR

    ],

    'reverse' => [

        'wins' =>
            $reverseWins,

        'losses' =>
            $reverseLoss,

        'wr' =>
            $reverseWR

    ]

];

file_put_contents(

    $outputFile,

    json_encode(
        $result,
        JSON_PRETTY_PRINT
    )

);

echo PHP_EOL;
echo "========================".PHP_EOL;
echo "REVERSE SIMULATOR".PHP_EOL;
echo "========================".PHP_EOL;

echo "Trades : ".$totalTrades.PHP_EOL;
echo "WAIT   : ".$waitSignals.PHP_EOL;

echo PHP_EOL;

echo "Consensus WR : "
    .$consensusWR."%".PHP_EOL;

echo "Reverse WR   : "
    .$reverseWR."%".PHP_EOL;

echo "========================".PHP_EOL;