<?php

error_reporting(E_ALL);

$tickFile =
    __DIR__.'/storage/historical_ticks.json';

$digitFile =
    __DIR__.'/storage/digit_scores.json';

$outputFile =
    __DIR__.'/storage/digit_context_result.json';

if(!file_exists($tickFile)){
    exit('historical_ticks.json NOT FOUND');
}

if(!file_exists($digitFile)){
    exit('digit_scores.json NOT FOUND');
}

$ticks =
    json_decode(
        file_get_contents($tickFile),
        true
    ) ?: [];

$digits =
    json_decode(
        file_get_contents($digitFile),
        true
    ) ?: [];

$totalTrades = 0;
$wins = 0;
$losses = 0;

$knowledgeStats = [];

for($i=0;$i<count($ticks)-10;$i++){

    $quote =
        (string)$ticks[$i]['quote'];

    $lastDigit =
        substr(
            preg_replace('/\D/','',$quote),
            -1
        );

    $best = null;
    $bestScore = 0;

    foreach($digits as $key=>$row){

        if(
            (string)$row['digit']
            !==
            $lastDigit
        ){
            continue;
        }

        if(
            ($row['score'] ?? 0)
            < 53
        ){
            continue;
        }

        if(
            ($row['samples'] ?? 0)
            < 200
        ){
            continue;
        }

        if(
            $row['score']
            >
            $bestScore
        ){

            $bestScore =
                $row['score'];

            $best =
                $row;

            $best['_key'] =
                $key;
        }
    }

    if(!$best){
        continue;
    }

    $duration =
        intval(
            $best['duration']
        );

    if(
        !isset(
            $ticks[
                $i+$duration
            ]
        )
    ){
        continue;
    }

    $entry =
        $ticks[$i]['quote'];

    $exit =
        $ticks[
            $i+$duration
        ]['quote'];

    $direction =
        $best['direction'];

    $win = false;

    if($direction === 'CALL'){

        $win =
            $exit > $entry;

    }else{

        $win =
            $exit < $entry;
    }

    $totalTrades++;

    if($win){
        $wins++;
    }else{
        $losses++;
    }

    $k =
        $best['_key'];

    if(!isset($knowledgeStats[$k])){

        $knowledgeStats[$k] = [

            'wins'=>0,
            'losses'=>0,
            'trades'=>0

        ];
    }

    $knowledgeStats[$k]['trades']++;

    if($win){

        $knowledgeStats[$k]['wins']++;

    }else{

        $knowledgeStats[$k]['losses']++;
    }
}

$wr = 0;

if($totalTrades > 0){

    $wr = round(

        ($wins/$totalTrades)*100,

        2

    );
}

$result = [

    'total_trades' =>
        $totalTrades,

    'wins' =>
        $wins,

    'losses' =>
        $losses,

    'wr' =>
        $wr,

    'knowledge_stats' =>
        $knowledgeStats

];

file_put_contents(

    $outputFile,

    json_encode(
        $result,
        JSON_PRETTY_PRINT
    )

);

echo PHP_EOL;
echo "========================".PHP_EOL;
echo "DIGIT CONTEXT SIM".PHP_EOL;
echo "========================".PHP_EOL;
echo "Trades : ".$totalTrades.PHP_EOL;
echo "Wins   : ".$wins.PHP_EOL;
echo "Losses : ".$losses.PHP_EOL;
echo "WR     : ".$wr."%".PHP_EOL;
echo "========================".PHP_EOL;
echo PHP_EOL;