<?php

$ticks = json_decode(
    file_get_contents(
        __DIR__.'/storage/ticks.json'
    ),
    true
) ?: [];

$context = json_decode(
    file_get_contents(
        __DIR__.'/storage/context.json'
    ),
    true
) ?: [];

if(count($ticks) < 30){
    exit('NOT ENOUGH TICKS');
}

/*
|--------------------------------------------------------------------------
| Context Labels
|--------------------------------------------------------------------------
*/

$rsiZone = 'RSI_MID';

$rsi =
    $context['rsi']
    ?? 50;

if($rsi >= 70){

    $rsiZone = 'RSI_HIGH';

}
elseif($rsi <= 30){

    $rsiZone = 'RSI_LOW';

}

$trend =
    $context['trend']
    ?? 'UNKNOWN';

$marketState =
    $context['market_state']
    ?? 'UNKNOWN';

/*
|--------------------------------------------------------------------------
| Research
|--------------------------------------------------------------------------
*/

$knowledge = [];

for($i=3; $i<count($ticks)-5; $i++){

    $t1 = $ticks[$i-3]['quote'];
    $t2 = $ticks[$i-2]['quote'];
    $t3 = $ticks[$i-1]['quote'];
    $t4 = $ticks[$i]['quote'];

    $pattern = '';

    $pattern .= ($t2 > $t1) ? 'U' : 'D';
    $pattern .= ($t3 > $t2) ? 'U' : 'D';
    $pattern .= ($t4 > $t3) ? 'U' : 'D';

    foreach(['CALL','PUT'] as $direction){

        for($duration=1; $duration<=5; $duration++){

            if(!isset($ticks[$i+$duration])){
                continue;
            }

            $entryPrice = $t4;
            $exitPrice  = $ticks[$i+$duration]['quote'];

            $key =
                $pattern
                .'|'
                .$direction
                .'|'
                .$duration
                .'|'
                .$rsiZone
                .'|'
                .$trend
                .'|'
                .$marketState;

            if(!isset($knowledge[$key])){

                $knowledge[$key] = [

                    'pattern' =>
                        $pattern,

                    'direction' =>
                        $direction,

                    'duration' =>
                        $duration,

                    'rsi_zone' =>
                        $rsiZone,

                    'trend' =>
                        $trend,

                    'market_state' =>
                        $marketState,

                    'win' => 0,
                    'loss' => 0,
                    'samples' => 0

                ];

            }

            $result = 'LOSS';

            if(
                $direction === 'CALL'
                &&
                $exitPrice > $entryPrice
            ){
                $result = 'WIN';
            }

            if(
                $direction === 'PUT'
                &&
                $exitPrice < $entryPrice
            ){
                $result = 'WIN';
            }

            $knowledge[$key]['samples']++;

            if($result === 'WIN'){
                $knowledge[$key]['win']++;
            }else{
                $knowledge[$key]['loss']++;
            }

        }

    }

}

/*
|--------------------------------------------------------------------------
| WR
|--------------------------------------------------------------------------
*/

foreach($knowledge as &$row){

    $total =
        $row['win']
        +
        $row['loss'];

    $row['wr'] =
        $total > 0
        ?
        round(
            ($row['win']/$total)*100,
            2
        )
        :
        0;

}

/*
|--------------------------------------------------------------------------
| Save
|--------------------------------------------------------------------------
*/

file_put_contents(

    __DIR__.'/storage/context_knowledge.json',

    json_encode(
        $knowledge,
        JSON_PRETTY_PRINT
    )

);

echo 'CONTEXT KNOWLEDGE UPDATED';