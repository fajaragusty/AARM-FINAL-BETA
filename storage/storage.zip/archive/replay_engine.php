<?php

$ticks = json_decode(
    file_get_contents(__DIR__.'/storage/ticks.json'),
    true
) ?: [];

if(count($ticks) < 20){
    exit('NOT ENOUGH TICKS');
}

$knowledge = [];

for($i=3; $i<count($ticks)-5; $i++){

    $t1 = $ticks[$i-3]['quote'];
    $t2 = $ticks[$i-2]['quote'];
    $t3 = $ticks[$i-1]['quote'];
    $t4 = $ticks[$i]['quote'];

    $pattern = '';

    $pattern .= ($t2 > $t1) ? 'U' : 'D';
    $pattern .= ($t3 > $t2) ? 'U' : 'D';
    $pattern .= ($t4 > $t3) ? 'U' : 'D';

    foreach(['CALL','PUT'] as $direction){

        for($duration=1; $duration<=5; $duration++){

            if(!isset($ticks[$i+$duration])){
                continue;
            }

            $entryPrice = $t4;
            $exitPrice  = $ticks[$i+$duration]['quote'];

            $key =
                $pattern
                .'_'
                .$direction
                .'_'
                .$duration;

            if(!isset($knowledge[$key])){

                $knowledge[$key] = [

                    'pattern'   => $pattern,
                    'direction' => $direction,
                    'duration'  => $duration,

                    'win'  => 0,
                    'loss' => 0,

                    'samples' => 0

                ];

            }

            $result = 'LOSS';

            if(
                $direction === 'CALL'
                &&
                $exitPrice > $entryPrice
            ){
                $result='WIN';
            }

            if(
                $direction === 'PUT'
                &&
                $exitPrice < $entryPrice
            ){
                $result='WIN';
            }

            $knowledge[$key]['samples']++;

            if($result==='WIN'){
                $knowledge[$key]['win']++;
            }else{
                $knowledge[$key]['loss']++;
            }

        }

    }

}

foreach($knowledge as &$row){

    $total =
        $row['win']
        +
        $row['loss'];

    $row['wr'] =
        $total > 0
        ?
        round(
            ($row['win']/$total)*100,
            2
        )
        :
        0;

}

/*
|--------------------------------------------------------------------------
| Save Knowledge
|--------------------------------------------------------------------------
*/

file_put_contents(

    __DIR__.'/storage/knowledge.json',

    json_encode(
        $knowledge,
        JSON_PRETTY_PRINT
    )

);

/*
|--------------------------------------------------------------------------
| Knowledge Timeline
|--------------------------------------------------------------------------
*/

$timelineFile =
    __DIR__.'/storage/knowledge_timeline.json';

$timeline = json_decode(
    file_get_contents($timelineFile),
    true
) ?: [];

$timestamp = time();

foreach($knowledge as $key => $row){

    if(!isset($timeline[$key])){
        $timeline[$key] = [];
    }

    $timeline[$key][] = [

        'time' =>
            $timestamp,

        'samples' =>
            $row['samples'],

        'wr' =>
            $row['wr']

    ];

    /*
    | Keep Last 100 Snapshots
    */

    if(
        count(
            $timeline[$key]
        ) > 100
    ){
        array_shift(
            $timeline[$key]
        );
    }

}

file_put_contents(

    $timelineFile,

    json_encode(
        $timeline,
        JSON_PRETTY_PRINT
    )

);

echo 'KNOWLEDGE + TIMELINE UPDATED';