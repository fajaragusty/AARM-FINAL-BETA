<?php

/*
|--------------------------------------------------------------------------
| ANTARTIKA
| Last2 Consistency Engine V2
|--------------------------------------------------------------------------
*/

$sourceFile =
    __DIR__.'/storage/last2_scores.json';

$outputFile =
    __DIR__.'/storage/last2_consistency_v2.json';

if(!file_exists($sourceFile)){
    exit('last2_scores.json NOT FOUND');
}

$data = json_decode(
    file_get_contents($sourceFile),
    true
) ?: [];

if(empty($data)){
    exit('NO LAST2 SCORE DATA');
}

$grouped = [];

/*
|--------------------------------------------------------------------------
| Group Last2
|--------------------------------------------------------------------------
*/

foreach($data as $key => $row){

    $last2 =
        $row['last2']
        ?? null;

    if(!$last2){
        continue;
    }

    if(!isset($grouped[$last2])){

        $grouped[$last2] = [

            'last2' => $last2,

            'scores' => [],

            'strong_durations' => 0,

            'best_score' => 0,

            'durations' => []

        ];

    }

    $score =
        $row['score']
        ?? 0;

    $duration =
        $row['duration']
        ?? 0;

    $grouped[$last2]['scores'][] =
        $score;

    $grouped[$last2]['durations'][$duration] =
        $score;

    if($score > $grouped[$last2]['best_score']){

        $grouped[$last2]['best_score'] =
            $score;

    }

}

/*
|--------------------------------------------------------------------------
| Consistency Analysis
|--------------------------------------------------------------------------
*/

$result = [];

foreach($grouped as $last2 => $info){

    $strongDurations = 0;

    foreach(
        $info['durations']
        as $duration => $score
    ){

        if($score >= 55){

            $strongDurations++;

        }

    }

    $avgScore = round(

        array_sum(
            $info['scores']
        )
        /
        count(
            $info['scores']
        ),

        2

    );

    $bestScore =
        $info['best_score'];

    /*
    |--------------------------------------------------------------------------
    | Consistency Formula V2
    |--------------------------------------------------------------------------
    */

    $consistencyScore = round(

        ($avgScore * 0.5)

        +

        ($bestScore * 0.3)

        +

        ($strongDurations * 5),

        2

    );

    /*
    |--------------------------------------------------------------------------
    | Rank
    |--------------------------------------------------------------------------
    */

    if($strongDurations >= 4){

        $rank = 'SURVIVOR';

    }
    elseif($strongDurations >= 3){

        $rank = 'STRONG';

    }
    elseif($strongDurations >= 2){

        $rank = 'OBSERVE';

    }
    else{

        $rank = 'WEAK';

    }

    $result[$last2] = [

        'last2' =>
            $last2,

        'avg_score' =>
            $avgScore,

        'best_score' =>
            $bestScore,

        'strong_durations' =>
            $strongDurations,

        'consistency_score' =>
            $consistencyScore,

        'rank' =>
            $rank

    ];

}

/*
|--------------------------------------------------------------------------
| Sort
|--------------------------------------------------------------------------
*/

uasort(

    $result,

    function($a,$b){

        return

            $b['consistency_score']

            <=>

            $a['consistency_score'];

    }

);

/*
|--------------------------------------------------------------------------
| Save
|--------------------------------------------------------------------------
*/

file_put_contents(

    $outputFile,

    json_encode(
        $result,
        JSON_PRETTY_PRINT

    )

);

echo 'LAST2 CONSISTENCY V2 UPDATED';