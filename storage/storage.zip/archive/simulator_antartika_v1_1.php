<?php

error_reporting(E_ALL);

/*
|--------------------------------------------------------------------------
| ANTARTIKA SIMULATOR V1.1
|--------------------------------------------------------------------------
| STRICT KNOWLEDGE FILTER
|--------------------------------------------------------------------------
*/

$tickFile =
    __DIR__.'/storage/historical_ticks.json';

$knowledgeFile =
    __DIR__.'/storage/knowledge_status.json';

$outputFile =
    __DIR__.'/storage/simulator_result_v11.json';

if(!file_exists($tickFile)){
    exit('historical_ticks.json NOT FOUND');
}

if(!file_exists($knowledgeFile)){
    exit('knowledge_status.json NOT FOUND');
}

$ticks = json_decode(
    file_get_contents($tickFile),
    true
) ?: [];

$knowledge = json_decode(
    file_get_contents($knowledgeFile),
    true
) ?: [];

if(count($ticks) < 100){
    exit('NOT ENOUGH TICKS');
}

/*
|--------------------------------------------------------------------------
| RSI ZONE
|--------------------------------------------------------------------------
*/

function getRsiZone($rsi)
{
    if($rsi < 20) return 'RSI_0_20';
    if($rsi < 40) return 'RSI_20_40';
    if($rsi < 60) return 'RSI_40_60';
    if($rsi < 80) return 'RSI_60_80';

    return 'RSI_80_100';
}

/*
|--------------------------------------------------------------------------
| Stats
|--------------------------------------------------------------------------
*/

$totalTrades = 0;
$wins = 0;
$losses = 0;

$knowledgeStats = [];

$skippedNoKnowledge = 0;
$skippedWeakKnowledge = 0;

/*
|--------------------------------------------------------------------------
| Simulation
|--------------------------------------------------------------------------
*/

for($i=3;$i<count($ticks)-10;$i++){

    $t1 = $ticks[$i-3]['quote'];
    $t2 = $ticks[$i-2]['quote'];
    $t3 = $ticks[$i-1]['quote'];
    $t4 = $ticks[$i]['quote'];

    $p1 = ($t2 > $t1) ? 'U' : 'D';
    $p2 = ($t3 > $t2) ? 'U' : 'D';
    $p3 = ($t4 > $t3) ? 'U' : 'D';

    $pattern = $p1.$p2.$p3;

    $bestKnowledge = null;
    $bestScore = 0;

    foreach($knowledge as $key => $row){

        if($row['pattern'] !== $pattern){
            continue;
        }

        /*
        |--------------------------------------------------------------------------
        | STRICT FILTER
        |--------------------------------------------------------------------------
        */

        if($row['status'] !== 'ACTIVE'){
            continue;
        }

        if(($row['score'] ?? 0) < 56){
            continue;
        }

        if(($row['confidence_score'] ?? 0) < 55){
            continue;
        }

        if(($row['samples'] ?? 0) < 100){
            continue;
        }

        if($row['score'] > $bestScore){

            $bestScore =
                $row['score'];

            $bestKnowledge =
                $row;

            $bestKnowledge['_key'] =
                $key;
        }
    }

    if(!$bestKnowledge){

        $skippedNoKnowledge++;
        continue;
    }

    $duration =
        intval(
            $bestKnowledge['duration']
        );

    if(
        !isset(
            $ticks[$i+$duration]
        )
    ){
        continue;
    }

    $entry =
        $ticks[$i]['quote'];

    $exit =
        $ticks[$i+$duration]['quote'];

    $direction =
        $bestKnowledge['direction'];

    $win = false;

    if($direction === 'CALL'){

        $win =
            $exit > $entry;

    }else{

        $win =
            $exit < $entry;
    }

    $totalTrades++;

    if($win){

        $wins++;

    }else{

        $losses++;
    }

    $k =
        $bestKnowledge['_key'];

    if(!isset($knowledgeStats[$k])){

        $knowledgeStats[$k] = [

            'wins'=>0,
            'losses'=>0,
            'trades'=>0

        ];
    }

    $knowledgeStats[$k]['trades']++;

    if($win){

        $knowledgeStats[$k]['wins']++;

    }else{

        $knowledgeStats[$k]['losses']++;
    }
}

/*
|--------------------------------------------------------------------------
| Best Knowledge
|--------------------------------------------------------------------------
*/

$bestKnowledge = '';
$bestWr = 0;

foreach($knowledgeStats as $key=>$row){

    if($row['trades'] < 20){
        continue;
    }

    $wr = round(
        ($row['wins']/$row['trades'])*100,
        2
    );

    if($wr > $bestWr){

        $bestWr = $wr;
        $bestKnowledge = $key;
    }
}

/*
|--------------------------------------------------------------------------
| Final WR
|--------------------------------------------------------------------------
*/

$wr = 0;

if($totalTrades > 0){

    $wr = round(
        ($wins/$totalTrades)*100,
        2
    );
}

$result = [

    'simulation_time' =>
        date('Y-m-d H:i:s'),

    'filter' => [

        'status' =>
            'ACTIVE',

        'score_min' =>
            56,

        'confidence_min' =>
            55,

        'samples_min' =>
            100

    ],

    'total_trades' =>
        $totalTrades,

    'wins' =>
        $wins,

    'losses' =>
        $losses,

    'wr' =>
        $wr,

    'skipped_no_knowledge' =>
        $skippedNoKnowledge,

    'best_knowledge' =>
        $bestKnowledge,

    'best_knowledge_wr' =>
        $bestWr,

    'knowledge_stats' =>
        $knowledgeStats

];

file_put_contents(

    $outputFile,

    json_encode(
        $result,
        JSON_PRETTY_PRINT
    )

);

echo PHP_EOL;
echo "==========================".PHP_EOL;
echo "ANTARTIKA SIMULATOR V1.1".PHP_EOL;
echo "==========================".PHP_EOL;
echo "Trades : ".$totalTrades.PHP_EOL;
echo "Wins   : ".$wins.PHP_EOL;
echo "Losses : ".$losses.PHP_EOL;
echo "WR     : ".$wr."%".PHP_EOL;
echo "==========================".PHP_EOL;
echo PHP_EOL;