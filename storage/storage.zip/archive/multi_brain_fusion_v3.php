<?php

/*
|--------------------------------------------------------------------------
| ANTARTIKA
| Multi Brain Fusion V3
|--------------------------------------------------------------------------
*/

$brainFile =
    __DIR__.'/storage/brain_state.json';

$confidenceFile =
    __DIR__.'/storage/confidence_scores.json';

$lifecycleFile =
    __DIR__.'/storage/knowledge_lifecycle.json';

$digitFile =
    __DIR__.'/storage/digit_scores.json';

$outputFile =
    __DIR__.'/storage/multi_brain_state_v3.json';

foreach([
    $brainFile,
    $confidenceFile,
    $lifecycleFile,
    $digitFile
] as $file){

    if(!file_exists($file)){
        exit(basename($file).' NOT FOUND');
    }

}

$brain =
    json_decode(
        file_get_contents($brainFile),
        true
    ) ?: [];

$confidence =
    json_decode(
        file_get_contents($confidenceFile),
        true
    ) ?: [];

$lifecycle =
    json_decode(
        file_get_contents($lifecycleFile),
        true
    ) ?: [];

$digits =
    json_decode(
        file_get_contents($digitFile),
        true
    ) ?: [];

$callWeight = 0;
$putWeight = 0;

$reasons = [];

/*
|--------------------------------------------------------------------------
| Pattern Brain
|--------------------------------------------------------------------------
*/

$patternKey =
    $brain['pattern_key']
    ?? null;

$patternVote =
    $brain['pattern_vote']
    ?? 'WAIT';

$patternScore =
    $brain['pattern_score']
    ?? 0;

if($patternVote === 'CALL'){

    $callWeight += $patternScore;

    $reasons[] =
        'Pattern CALL '.$patternScore;

}
elseif($patternVote === 'PUT'){

    $putWeight += $patternScore;

    $reasons[] =
        'Pattern PUT '.$patternScore;

}

/*
|--------------------------------------------------------------------------
| Digit Brain
|--------------------------------------------------------------------------
*/

$digitKey =
    $brain['digit_key']
    ?? null;

$digitVote =
    $brain['digit_vote']
    ?? 'WAIT';

$digitScore =
    $brain['digit_score']
    ?? 0;

if($digitVote === 'CALL'){

    $callWeight += $digitScore;

    $reasons[] =
        'Digit CALL '.$digitScore;

}
elseif($digitVote === 'PUT'){

    $putWeight += $digitScore;

    $reasons[] =
        'Digit PUT '.$digitScore;

}

/*
|--------------------------------------------------------------------------
| Confidence Multiplier
|--------------------------------------------------------------------------
*/

$confidenceMultiplier = 1.0;

if(
    $patternKey
    &&
    isset($confidence[$patternKey])
){

    $conf =
        $confidence[$patternKey]
        ['confidence_score']
        ?? 0;

    if($conf >= 55){

        $confidenceMultiplier = 1.20;

    }
    elseif($conf >= 45){

        $confidenceMultiplier = 1.10;

    }
    elseif($conf < 30){

        $confidenceMultiplier = 0.80;

    }

}

/*
|--------------------------------------------------------------------------
| Lifecycle Multiplier
|--------------------------------------------------------------------------
*/

$lifecycleMultiplier = 1.0;

if(
    $patternKey
    &&
    isset($lifecycle[$patternKey])
){

    $status =
        $lifecycle[$patternKey]
        ['status']
        ?? '';

    if($status === 'ACTIVE'){

        $lifecycleMultiplier = 1.15;

    }
    elseif($status === 'DECAYING'){

        $lifecycleMultiplier = 0.95;

    }
    elseif($status === 'DEAD'){

        $lifecycleMultiplier = 0.75;

    }
    elseif($status === 'GRAVEYARD'){

        $lifecycleMultiplier = 0.50;

    }

}

/*
|--------------------------------------------------------------------------
| Apply Multipliers
|--------------------------------------------------------------------------
*/

$callWeight =
    round(
        $callWeight
        *
        $confidenceMultiplier
        *
        $lifecycleMultiplier,
        2
    );

$putWeight =
    round(
        $putWeight
        *
        $confidenceMultiplier
        *
        $lifecycleMultiplier,
        2
    );

/*
|--------------------------------------------------------------------------
| Delta Analysis
|--------------------------------------------------------------------------
*/

$delta =
    abs(
        $callWeight
        -
        $putWeight
    );

$decision = 'WAIT';

if($delta < 10){

    $decision = 'WAIT';

}
else{

    if($callWeight > $putWeight){

        $decision =
            'FOLLOW_CALL';

    }else{

        $decision =
            'FOLLOW_PUT';

    }

}

/*
|--------------------------------------------------------------------------
| Confidence %
|--------------------------------------------------------------------------
*/

$total =
    $callWeight
    +
    $putWeight;

$confidencePercent = 0;

if($total > 0){

    $confidencePercent =
        round(
            (
                max(
                    $callWeight,
                    $putWeight
                )
                /
                $total
            ) * 100,
            2
        );

}

/*
|--------------------------------------------------------------------------
| Save
|--------------------------------------------------------------------------
*/

$result = [

    'time' =>
        date('Y-m-d H:i:s'),

    'call_weight' =>
        $callWeight,

    'put_weight' =>
        $putWeight,

    'delta' =>
        $delta,

    'decision' =>
        $decision,

    'confidence' =>
        $confidencePercent,

    'confidence_multiplier' =>
        $confidenceMultiplier,

    'lifecycle_multiplier' =>
        $lifecycleMultiplier,

    'reasons' =>
        $reasons

];

file_put_contents(

    $outputFile,

    json_encode(
        $result,
        JSON_PRETTY_PRINT
    )

);

echo 'MULTI BRAIN FUSION V3 UPDATED';