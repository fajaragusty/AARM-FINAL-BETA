<?php

/*
|--------------------------------------------------------------------------
| ANTARTIKA
| Reverse Hypothesis Engine V1
|--------------------------------------------------------------------------
*/

$statusFile =
    __DIR__.'/storage/knowledge_status.json';

$timelineFile =
    __DIR__.'/storage/knowledge_timeline.json';

$outputFile =
    __DIR__.'/storage/reverse_hypothesis.json';

foreach([
    $statusFile,
    $timelineFile
] as $file){

    if(!file_exists($file)){
        exit(
            basename($file)
            .' NOT FOUND'
        );
    }

}

$statusData =
    json_decode(
        file_get_contents($statusFile),
        true
    ) ?: [];

$timelineData =
    json_decode(
        file_get_contents($timelineFile),
        true
    ) ?: [];

$result = [];

foreach($statusData as $key => $row){

    if(
        !isset(
            $timelineData[$key]
        )
    ){
        continue;
    }

    $history =
        $timelineData[$key];

    if(
        count($history) < 3
    ){
        continue;
    }

    /*
    |--------------------------------------------------------------------------
    | Last 3 Scores
    |--------------------------------------------------------------------------
    */

    $last3 =
        array_slice(
            $history,
            -3
        );

    $s1 =
        $last3[0]['score'] ?? 0;

    $s2 =
        $last3[1]['score'] ?? 0;

    $s3 =
        $last3[2]['score'] ?? 0;

    $trend = 'FLAT';

    if(
        $s1 > $s2
        &&
        $s2 > $s3
    ){
        $trend = 'DECAYING';
    }

    if(
        $s1 < $s2
        &&
        $s2 < $s3
    ){
        $trend = 'GROWING';
    }

    /*
    |--------------------------------------------------------------------------
    | Reverse Status
    |--------------------------------------------------------------------------
    */

    $reverseStatus =
        'NO_SIGNAL';

    if(
        $trend === 'DECAYING'
        &&
        $row['status'] === 'ACTIVE'
    ){

        $reverseStatus =
            'WATCH';

    }

    if(
        $trend === 'DECAYING'
        &&
        $row['score'] < 55
    ){

        $reverseStatus =
            'REVERSE_READY';

    }

    /*
    |--------------------------------------------------------------------------
    | Reverse Key
    |--------------------------------------------------------------------------
    */

    $reverseDirection =
        (
            $row['direction']
            === 'CALL'
        )
        ? 'PUT'
        : 'CALL';

    $reverseKey =
        str_replace(
            '|'.$row['direction'].'|',
            '|'.$reverseDirection.'|',
            $key
        );

    $result[$key] = [

        'current_direction' =>
            $row['direction'],

        'reverse_direction' =>
            $reverseDirection,

        'score' =>
            $row['score'],

        'status' =>
            $row['status'],

        'trend' =>
            $trend,

        'reverse_status' =>
            $reverseStatus,

        'reverse_key' =>
            $reverseKey

    ];

}

/*
|--------------------------------------------------------------------------
| Sort
|--------------------------------------------------------------------------
*/

uasort(

    $result,

    function($a,$b){

        $rank = [

            'REVERSE_READY' => 3,
            'WATCH' => 2,
            'NO_SIGNAL' => 1
        ];

        return

            $rank[
                $b['reverse_status']
            ]

            <=>

            $rank[
                $a['reverse_status']
            ];

    }

);

file_put_contents(

    $outputFile,

    json_encode(
        $result,
        JSON_PRETTY_PRINT
    )

);

echo 'REVERSE HYPOTHESIS UPDATED';