<?php

/*
|--------------------------------------------------------------------------
| ANTARTIKA
| Multi Brain Fusion V2
|--------------------------------------------------------------------------
*/

$brainFile =
    __DIR__.'/storage/brain_state.json';

$confidenceFile =
    __DIR__.'/storage/confidence_scores.json';

$lifecycleFile =
    __DIR__.'/storage/knowledge_lifecycle.json';

$outputFile =
    __DIR__.'/storage/multi_brain_state.json';

if(!file_exists($brainFile)){
    exit('brain_state.json NOT FOUND');
}

if(!file_exists($confidenceFile)){
    exit('confidence_scores.json NOT FOUND');
}

if(!file_exists($lifecycleFile)){
    exit('knowledge_lifecycle.json NOT FOUND');
}

$brain =
    json_decode(
        file_get_contents($brainFile),
        true
    ) ?: [];

$confidence =
    json_decode(
        file_get_contents($confidenceFile),
        true
    ) ?: [];

$lifecycle =
    json_decode(
        file_get_contents($lifecycleFile),
        true
    ) ?: [];

$callVotes = 0;
$putVotes = 0;

$reasons = [];

/*
|--------------------------------------------------------------------------
| Pattern Brain Vote
|--------------------------------------------------------------------------
*/

if(
    ($brain['pattern_vote'] ?? '')
    ===
    'CALL'
){

    $callVotes += 2;

    $reasons[] =
        'Pattern Brain CALL';

}
elseif(
    ($brain['pattern_vote'] ?? '')
    ===
    'PUT'
){

    $putVotes += 2;

    $reasons[] =
        'Pattern Brain PUT';

}

/*
|--------------------------------------------------------------------------
| Digit Brain Vote
|--------------------------------------------------------------------------
*/

if(
    ($brain['digit_vote'] ?? '')
    ===
    'CALL'
){

    $callVotes += 1;

    $reasons[] =
        'Digit Brain CALL';

}
elseif(
    ($brain['digit_vote'] ?? '')
    ===
    'PUT'
){

    $putVotes += 1;

    $reasons[] =
        'Digit Brain PUT';

}

/*
|--------------------------------------------------------------------------
| Confidence Brain
|--------------------------------------------------------------------------
*/

$patternKey =
    $brain['pattern_key']
    ?? null;

if(
    $patternKey
    &&
    isset(
        $confidence[$patternKey]
    )
){

    $conf =
        $confidence[$patternKey]
        ['confidence_score']
        ?? 0;

    if($conf >= 55){

        if(
            $brain['pattern_vote']
            === 'CALL'
        ){

            $callVotes += 2;

        }
        else{

            $putVotes += 2;

        }

        $reasons[] =
            'High Confidence';

    }

}

/*
|--------------------------------------------------------------------------
| Lifecycle Brain
|--------------------------------------------------------------------------
*/

if(
    $patternKey
    &&
    isset(
        $lifecycle[$patternKey]
    )
){

    $status =
        $lifecycle[$patternKey]
        ['status']
        ?? '';

    if(
        $status
        ===
        'ACTIVE'
    ){

        if(
            $brain['pattern_vote']
            === 'CALL'
        ){

            $callVotes += 2;

        }
        else{

            $putVotes += 2;

        }

        $reasons[] =
            'Lifecycle ACTIVE';

    }

    if(
        $status
        ===
        'DECAYING'
    ){

        if(
            $brain['pattern_vote']
            === 'CALL'
        ){

            $callVotes += 1;

        }
        else{

            $putVotes += 1;

        }

        $reasons[] =
            'Lifecycle DECAYING';

    }

}

/*
|--------------------------------------------------------------------------
| Final Decision
|--------------------------------------------------------------------------
*/

$decision = 'WAIT';

if(
    abs(
        $callVotes -
        $putVotes
    ) < 2
){

    $decision = 'WAIT';

}
elseif(
    $callVotes >
    $putVotes
){

    $decision = 'FOLLOW_CALL';

}
else{

    $decision = 'FOLLOW_PUT';

}

/*
|--------------------------------------------------------------------------
| Strength
|--------------------------------------------------------------------------
*/

$totalVotes =
    $callVotes
    +
    $putVotes;

$confidencePercent = 0;

if($totalVotes > 0){

    $confidencePercent =
        round(

            (
                max(
                    $callVotes,
                    $putVotes
                )
                /
                $totalVotes
            ) * 100,

            2

        );

}

/*
|--------------------------------------------------------------------------
| Save
|--------------------------------------------------------------------------
*/

$result = [

    'time' =>
        date(
            'Y-m-d H:i:s'
        ),

    'call_votes' =>
        $callVotes,

    'put_votes' =>
        $putVotes,

    'decision' =>
        $decision,

    'confidence' =>
        $confidencePercent,

    'reasons' =>
        $reasons

];

file_put_contents(

    $outputFile,

    json_encode(
        $result,
        JSON_PRETTY_PRINT
    )

);

echo 'MULTI BRAIN FUSION V2 UPDATED';