<?php

error_reporting(E_ALL);

/*
|--------------------------------------------------------------------------
| ANTARTIKA ADAPTIVE CONSENSUS SIMULATOR
|--------------------------------------------------------------------------
*/

$consensusFile =
    __DIR__.'/storage/consensus_simulator_result.json';

$patternFile =
    __DIR__.'/storage/simulator_context_result.json';

$digitFile =
    __DIR__.'/storage/digit_context_result.json';

$outputFile =
    __DIR__.'/storage/adaptive_consensus_result.json';

foreach([
    $consensusFile,
    $patternFile,
    $digitFile
] as $file){

    if(!file_exists($file)){
        exit(
            basename($file)
            .' NOT FOUND'
        );
    }
}

$consensus =
    json_decode(
        file_get_contents($consensusFile),
        true
    );

$pattern =
    json_decode(
        file_get_contents($patternFile),
        true
    );

$digit =
    json_decode(
        file_get_contents($digitFile),
        true
    );

/*
|--------------------------------------------------------------------------
| Current WR
|--------------------------------------------------------------------------
*/

$patternWR =
    $pattern['wr'] ?? 0;

$digitWR =
    $digit['wr'] ?? 0;

$consensusWR =
    $consensus['wr'] ?? 0;

/*
|--------------------------------------------------------------------------
| Adaptive Weight
|--------------------------------------------------------------------------
*/

$total =
    $patternWR + $digitWR;

$patternWeight =
    round(
        ($patternWR / $total) * 100,
        2
    );

$digitWeight =
    round(
        ($digitWR / $total) * 100,
        2
    );

/*
|--------------------------------------------------------------------------
| Adaptive Score
|--------------------------------------------------------------------------
*/

$adaptiveWR =
    round(

        (
            ($patternWR * $patternWeight)
            +
            ($digitWR * $digitWeight)
        ) / 100,

        2

    );

/*
|--------------------------------------------------------------------------
| Improvement
|--------------------------------------------------------------------------
*/

$improvement =
    round(
        $adaptiveWR
        -
        $consensusWR,
        2
    );

/*
|--------------------------------------------------------------------------
| Verdict
|--------------------------------------------------------------------------
*/

$verdict =
    'NO_GAIN';

if(
    $adaptiveWR
    >
    $consensusWR
){
    $verdict =
        'IMPROVED';
}

$result = [

    'pattern_wr' =>
        $patternWR,

    'digit_wr' =>
        $digitWR,

    'consensus_wr' =>
        $consensusWR,

    'adaptive_wr' =>
        $adaptiveWR,

    'pattern_weight' =>
        $patternWeight,

    'digit_weight' =>
        $digitWeight,

    'improvement' =>
        $improvement,

    'verdict' =>
        $verdict

];

file_put_contents(

    $outputFile,

    json_encode(
        $result,
        JSON_PRETTY_PRINT
    )

);

echo PHP_EOL;

echo "======================".PHP_EOL;
echo "ADAPTIVE CONSENSUS".PHP_EOL;
echo "======================".PHP_EOL;

echo "Pattern WR : "
    .$patternWR."%".PHP_EOL;

echo "Digit WR   : "
    .$digitWR."%".PHP_EOL;

echo "Consensus  : "
    .$consensusWR."%".PHP_EOL;

echo PHP_EOL;

echo "Pattern Weight : "
    .$patternWeight."%".PHP_EOL;

echo "Digit Weight   : "
    .$digitWeight."%".PHP_EOL;

echo PHP_EOL;

echo "Adaptive WR : "
    .$adaptiveWR."%".PHP_EOL;

echo "Improvement : "
    .$improvement."%".PHP_EOL;

echo PHP_EOL;

echo "Verdict : "
    .$verdict.PHP_EOL;

echo "======================".PHP_EOL;